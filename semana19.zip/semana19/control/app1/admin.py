from django.contrib import admin
from .models import Productos,Proveedores



admin.site.register(Productos)
admin.site.register(Proveedores)

# Register your models here.
